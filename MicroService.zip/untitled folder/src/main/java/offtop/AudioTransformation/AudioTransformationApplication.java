package offtop.AudioTransformation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AudioTransformationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AudioTransformationApplication.class, args);
	}

}
