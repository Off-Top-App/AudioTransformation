package offtop.AudioTransformation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AudioTransformationApplicationTests {

	@Test
	void contextLoads() {
	}

}
